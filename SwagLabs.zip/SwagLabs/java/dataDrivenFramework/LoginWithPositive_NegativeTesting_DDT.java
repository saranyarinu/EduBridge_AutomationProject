package dataDrivenFramework;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import repository_POM_PageFactory.POM_SwagLabs;


public class LoginWithPositive_NegativeTesting_DDT 
{

	public static void main(String[] args) throws Exception 
	{
		//Store Excel File path
				FileInputStream file=new FileInputStream("C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\POI\\Book1.xlsx");
				XSSFWorkbook w = new XSSFWorkbook(file);
				
				//Reach to DDT Excel Sheet
				XSSFSheet s = w.getSheet("Sheet1");
				
				//Store last row value >> End range in For loop
				int size=s.getLastRowNum();
				System.out.println("No of Data: "+size);
				
				//Launch Browser
				System.setProperty("webdriver.chrome.driver","C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
				WebDriver driver= new ChromeDriver();
				
				//Create object of POM class >> Repository
				POM_SwagLabs p = new POM_SwagLabs();
				
				//For Loop
				for(int i=1; i<=size; i++)
				{
					String username=s.getRow(i).getCell(0).getStringCellValue();
					String password=s.getRow(i).getCell(1).getStringCellValue();
					System.out.println(username+"\t\t\t"+password);
					
					//To handle runtime exception >> because of negative testing (Invalid Credentials) 
					try
					{
						//Login
						p.maximizeBrowser(driver);
						p.deleteAllCookies(driver);
						p.implicitWait(driver);
						p.url(driver);
						p.username(driver, username);
						p.password(driver, password);
						p.loginButton(driver);
						Thread.sleep(2000);
						p.admin(driver);
						Thread.sleep(2000);
						p.logout(driver);
						Thread.sleep(2000);
						System.out.println("Valid Credentials");//updating test results on console
						System.out.println("");
						s.getRow(i).createCell(2).setCellValue("Valid Credentials");
					}
					
				catch (Exception e)
					{
					 	System.out.println("Invalid Credentials");//updating test results on console
					 	System.out.println("");
					 	s.getRow(i).createCell(2).setCellValue("Invalid Credentials");
					}
					}
				
				//Permission to update Test Result
				FileOutputStream out = new FileOutputStream("C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\POI\\Book1.xlsx");
				w.write(out);
				
				//Close Browser
				p.closeBrowser(driver);

	}

}
