package basicFunctionalities;

import org.testng.annotations.Test;

import repository_POM_PageFactory.POM_SwagLabs;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class MultipleTestCases {
	
  WebDriver driver;
  @BeforeTest
  public void beforeTest() 
  {
	    System.setProperty("webdriver.chrome.driver", "C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
  }

  @Test(priority=1, description="Checking Login Functionality")//Main Method
  public void SwagLabsLogin() throws Exception 
  {
	  POM_SwagLabs p=new POM_SwagLabs();
	    //p.implicitWait(driver);
		p.url(driver);
		p.username(driver, "standard_user");
		p.password(driver, "secret_sauce");
		p.loginButton(driver);
		p.admin(driver);
		p.logout(driver);
  } 
  
  @Test(priority=2, description="AddToCart")//Main Method
  public void addToCart() throws InterruptedException
  {
	  driver.navigate().to("https://saucedemo.com/");
		
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
	
		driver.findElement(By.id("login-button")).click();
		
		driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("add-to-cart-sauce-labs-bolt-t-shirt")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@class='shopping_cart_badge']")).click();
		Thread.sleep(2000);
		
		//Navigate Commands
		//Back
		driver.navigate().back();
		//Forward
		driver.navigate().forward();
		//Refresh
		driver.navigate().refresh();
		//URL
		driver.navigate().to("https://www.saucedemo.com/inventory.html");
		
		driver.findElement(By.id("react-burger-menu-btn")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("logout_sidebar_link")).click();
		
		Thread.sleep(2000);
  }
  
  
  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
