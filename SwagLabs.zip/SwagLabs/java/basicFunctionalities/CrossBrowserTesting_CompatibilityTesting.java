package basicFunctionalities;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.time.Duration;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;

public class CrossBrowserTesting_CompatibilityTesting 
{
	 WebDriver driver = null;//Globally Declaration
  @Test
 
  public void f() throws InterruptedException 
  {
	  driver.navigate().to("https://saucedemo.com/");
		
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
	
		driver.findElement(By.id("login-button")).click();
		
		driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("add-to-cart-sauce-labs-bolt-t-shirt")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@class='shopping_cart_badge']")).click();
		Thread.sleep(2000);
		
		//Navigate Commands
		//Back
		driver.navigate().back();
		//Forward
		driver.navigate().forward();
		//Refresh
		driver.navigate().refresh();
		//URL
		driver.navigate().to("https://www.saucedemo.com/inventory.html");
		
		driver.findElement(By.id("react-burger-menu-btn")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("logout_sidebar_link")).click();
		
		Thread.sleep(2000);
  }
  @BeforeTest
  public void beforeTest() 
  {
	  Scanner s= new Scanner(System.in);
		System.out.println("Enter 1 for GoogleChrome.\nEnter 2 for MozillaFirfox.\nEnter 3 for MSEdge.");
		int choice=s.nextInt();
		
		
		switch(choice)
		{
		case 1:
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
			driver = new ChromeDriver();
			System.out.println("***Welcome to Google Chrome***");
			break;
			
		case 2:
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\geckodriver.exe");
			driver = new FirefoxDriver();
			System.out.println("***Welcome to Mozilla Firfox***");
			break;
			
		case 3:
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\msedgedriver.exe");
			driver = new EdgeDriver();
			System.out.println("***Welcome to MSEdge***");
			break;
		
			default:
				System.out.println("Incorrect Input..");
		}
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
  }

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
