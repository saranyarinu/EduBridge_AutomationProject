package basicFunctionalities;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class SmokeTesting_MouseHover 
{
	WebDriver driver;
	@BeforeTest
	  public void beforeTest() 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
	}
  @Test
  public void f() throws InterruptedException 
  {
	  driver.navigate().to("https://saucedemo.com/");
		
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
	
		driver.findElement(By.id("login-button")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("react-burger-menu-btn")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("inventory_sidebar_link")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("about_sidebar_link")).click();
		Thread.sleep(2000);
		driver.navigate().back();
		driver.findElement(By.id("react-burger-menu-btn")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("reset_sidebar_link")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("logout_sidebar_link")).click();
  }
  

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
