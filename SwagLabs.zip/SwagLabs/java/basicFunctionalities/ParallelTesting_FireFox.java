package basicFunctionalities;

import org.testng.annotations.Test;

import repository_POM_PageFactory.POM_SwagLabs;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;

public class ParallelTesting_FireFox
{
	WebDriver driver;
	  @BeforeTest
	  public void beforeTest() 
	  {
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\geckodriver.exe");
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
	  }
	  
@Test(dataProvider = "dp", description="Checking Login Functionality of SwagLab with Multiple Credentials")
public void swagLab(String username, String password) throws Exception 
{
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  POM_SwagLabs p=new POM_SwagLabs();
	    //p.implicitWait(driver);
		p.url(driver);
		p.username(driver, username);
		p.password(driver, password);
		Thread.sleep(2000);
		p.loginButton(driver);
		p.admin(driver);
		Thread.sleep(2000);
		p.logout(driver);
}


@DataProvider//Test Management which is 2D array stores username and password.
public Object[][] dp() 
{
  return new Object[][] 
  {
    new Object[] { "standard_user", "secret_sauce" },
    new Object[] { "locked_out_user", "secret_sauce" },
    new Object[] { "problem_user", "secret_sauce" },
    new Object[] { "performance_glitch_user", "secret_sauce" },
    new Object[] { "error_user", "secret_sauce" },
    new Object[] { "visual_user", "secret_sauce" }
  };
}


@AfterTest
public void afterTest() 
{
	  driver.close();
}
}
