package basicFunctionalities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class URLVerification 
{

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		String expectedURL="https://www.saucedemo.com/";
		System.out.println("Expected URL: "+expectedURL);
		//URL
		driver.get(expectedURL);
		
		String actualURL=driver.getCurrentUrl();
		System.out.println("Actual URL: "+actualURL);
		
		//URL Validation
		if(expectedURL.equals(actualURL))
		{
			System.out.println("URL Validation is Passed.");
		}
		else
		{
			System.out.println("URL Validation is Failed.");
		}
	}

}
