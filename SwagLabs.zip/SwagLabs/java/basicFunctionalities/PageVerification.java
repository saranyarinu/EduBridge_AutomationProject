package basicFunctionalities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PageVerification 
{

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.get("https://saucedemo.com/");	
		
		String expectedTitle="Swag Labs";
		System.out.println("Expected WebpageTitle: "+expectedTitle);
		String actualTitle=driver.getTitle();
		System.out.println("Actual WebpageTitle: "+actualTitle);
		
		if(expectedTitle.equals(actualTitle))
		{
			System.out.println("WebpageTitle Validation is Passed.");
		}
		else
		{
			System.out.println("WebpageTitle Validation is Failed.");
		}

	}

}
