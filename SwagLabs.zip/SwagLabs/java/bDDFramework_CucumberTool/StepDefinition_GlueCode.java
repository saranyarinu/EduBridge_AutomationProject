package bDDFramework_CucumberTool;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition_GlueCode 
{
	WebDriver driver;
	
	@Given("Useris on login page")
	public void useris_on_login_page() 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/");
	}
	
	@Given("URL Verification")
	public void url_verification() 
	{
		String expectedURL="https://www.saucedemo.com/";
		System.out.println("\nExpected URL: "+expectedURL);
		//URL
		driver.get(expectedURL);
		
		String actualURL=driver.getCurrentUrl();
		System.out.println("Actual URL: "+actualURL);
		
		//URL Validation
		if(expectedURL.equals(actualURL))
		{
			System.out.println("URL Validation is Passed.\n");
		}
		else
		{
			System.out.println("URL Validation is Failed.\n");
		}
	}
	
	@Given("Page Title Verification")
	public void page_title_verification() 
	{
		String expectedTitle="Swag Labs";
		System.out.println("\nExpected WebpageTitle: "+expectedTitle);
		String actualTitle=driver.getTitle();
		System.out.println("Actual WebpageTitle: "+actualTitle);
		
		if(expectedTitle.equals(actualTitle))
		{
			System.out.println("WebpageTitle Validation is Passed.\n");
		}
		else
		{
			System.out.println("WebpageTitle Validation is Failed.\n");
		}
	}

	@When("User enters username and password")
	public void user_enters_username_and_password()
	{
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
	}

	@When("click on login button")
	public void click_on_login_button() 
	{
		driver.findElement(By.id("login-button")).click();
	}

	@Then("User will navigate to Home page")
	public void user_will_navigate_to_home_page() throws InterruptedException 
	{
		driver.findElement(By.id("react-burger-menu-btn")).click();
		driver.findElement(By.id("about_sidebar_link")).click();
		Thread.sleep(2000);
		driver.navigate().back();
		
	}

	@Then("User will apply filter")
	public void user_will_apply_filter() throws InterruptedException 
	{
		Thread.sleep(2000);
		Select s=new Select(driver.findElement(By.xpath("//select[@class='product_sort_container']")));
		Thread.sleep(2000);
		s.selectByVisibleText("Price (high to low)");
		Thread.sleep(2000);
	}

	@Then("User will add products to cart")
	public void user_will_add_products_to_cart() throws InterruptedException 
	{
		Thread.sleep(2000);
		driver.findElement(By.id("add-to-cart-sauce-labs-fleece-jacket")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
	}
	
	@Then("User will click on the cart to checkout")
	public void user_will_click_on_the_cart_to_checkout() throws InterruptedException 
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("checkout")).click();
	}

	@Then("User will give checkout information")
	public void user_will_give_checkout_information() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.id("first-name")).sendKeys("Saranya");
		driver.findElement(By.id("last-name")).sendKeys("Rajendran");
		driver.findElement(By.id("postal-code")).sendKeys("643211");
		driver.findElement(By.id("continue")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("finish")).click();
	}

	@Then("User will continue shopping")
	public void user_will_continue_shopping() throws InterruptedException 
	{
		Thread.sleep(2000);
		driver.findElement(By.id("back-to-products")).click();
	}



	@Then("User will logout")
	public void user_will_logout() throws InterruptedException 
	{
		Thread.sleep(2000);
		driver.findElement(By.id("react-burger-menu-btn")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("logout_sidebar_link")).click();
	}

}
