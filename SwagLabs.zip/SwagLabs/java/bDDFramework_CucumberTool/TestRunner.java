package bDDFramework_CucumberTool;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="src\\test\\resources\\BDD_Documents\\Login.feature", glue="bDDFramework_CucumberTool",
monochrome = true,
plugin= {"pretty", "html:src/test/resources/Login.html",
		"json:src/test/resources/Login.json",
		"junit:src/test/resources/Login.junit"
}
)
public class TestRunner 
{

}
