package mainFunctionalities;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class SearchForProduct_ProductDescription 
{
	WebDriver driver;
	@BeforeTest
	  public void beforeTest() 
	  {
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
	  }
  @Test
  public void f() throws InterruptedException 
  {
	  driver.navigate().to("https://saucedemo.com/");
		
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
	
		driver.findElement(By.id("login-button")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("back-to-products")).click();
		driver.findElement(By.id("react-burger-menu-btn")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("logout_sidebar_link")).click();
			
		Thread.sleep(2000);
  }
  

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
