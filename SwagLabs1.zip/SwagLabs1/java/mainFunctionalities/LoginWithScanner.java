package mainFunctionalities;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.Scanner;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class LoginWithScanner 
{
	String usr,pwd;
	WebDriver driver;
	 @BeforeTest
	  public void beforeTest() 
	  {
		 Scanner s = new Scanner(System.in);
			System.out.println("Enter the username and password:");
			usr=s.next();
			pwd=s.next();
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
	  }
  @Test
  public void f() throws InterruptedException 
  {
	    driver.navigate().to("https://saucedemo.com/");
	    Thread.sleep(2000);
	    driver.findElement(By.id("user-name")).sendKeys(usr);
		
		driver.findElement(By.id("password")).sendKeys(pwd);
	
		Thread.sleep(2000);
		driver.findElement(By.id("login-button")).click();
		
		Thread.sleep(2000);
		
		driver.findElement(By.id("react-burger-menu-btn")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("logout_sidebar_link")).click();
		Thread.sleep(2000);
  }
 

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
