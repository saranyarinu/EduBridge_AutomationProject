package keywordDrivenFramework;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class ReadExcelClass 
{
	public void readExcel(WebDriver driver) throws Exception
	{
		Select d;
		FileInputStream file=new FileInputStream("C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\POI\\POI.xlsx");
		XSSFWorkbook w = new XSSFWorkbook(file);
		XSSFSheet s = w.getSheet("Sheet1");
		
		int size=s.getLastRowNum();
		System.out.println("No of Keywords: "+size);
		
		OperationalClass o= new OperationalClass();
		
		for(int i=1; i<=size; i++)
		{
			//Store keywords in variables
			String key=s.getRow(i).getCell(0).getStringCellValue();
			System.out.println(key);
			
			//Execute process as per the excel sheet keywords with operational class methods: Condional statements
			if(key.equals("Maximize Browser"))
			{
				o.maximizeBrowser(driver);
			}
			else if(key.equals("Delete All Cookies"))
			{
				o.deleteAllCookies(driver);
			}
			else if(key.equals("Enter URL"))
			{
				o.url(driver);
				Thread.sleep(2000);
			}
			else if(key.equals("Enter Username"))
			{
				o.username(driver, "standard_user");
			}
			else if(key.equals("Enter Password"))
			{
				o.password(driver, "secret_sauce");
			}
			else if(key.equals("Click On Login Button"))
			{
				o.loginButton(driver);
				Thread.sleep(2000);
			}
			else if(key.equals("Click On Login Button"))
			{
				o.loginButton(driver);
				Thread.sleep(2000);
			}
			else if(key.equals("Click On Filter"))
			{
				d=new Select(driver.findElement(By.xpath("//select[@class='product_sort_container']")));
				d.selectByVisibleText("Price (high to low)");
				Thread.sleep(2000);
			}
			else if(key.equals("Click On Admin Button"))
			{
				o.admin(driver);
				Thread.sleep(2000);
			}
			else if(key.equals("Click On Logout Button"))
			{
				o.logout(driver);
				Thread.sleep(2000);
			}
			else if(key.equals("Close Browser"))
			{
				o.closeBrowser(driver);
			}
		}
		
	}
}
