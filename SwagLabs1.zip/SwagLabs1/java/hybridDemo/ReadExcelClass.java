package hybridDemo;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;


public class ReadExcelClass 
{
	 public void readExcel(WebDriver driver) throws Exception
	  {
		  FileInputStream file = new FileInputStream("C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\POI\\POI.xlsx");
		  XSSFWorkbook w = new XSSFWorkbook(file) ;
		  XSSFSheet s= w.getSheet("Hybrid");
		  
		  int size=s.getLastRowNum();
		  System.out.println("No of rows: "+size);
		  
		  OperationalClass o = new OperationalClass();
		  
		  for(int i=1; i<=size; i++)
		  {
			  String username=s.getRow(i).getCell(1).getStringCellValue();
			  String password=s.getRow(i).getCell(2).getStringCellValue();
			  System.out.println(username+"\t\t"+password);
			  
			  for(int j=1; j<=size; j++)
			  {
				  String key=s.getRow(j).getCell(0).getStringCellValue();
				  
				  try
				  {
					  if(key.equals("Maximize Browser"))
					  {
						  o.maximizeBrowser(driver);
						  System.out.println(key);
						  
					  }
					  else if(key.equals("Delete All Cookies"))
					  {
						  o.deleteAllCookies(driver);
						  System.out.println(key);
					  }
					  else if(key.equals("Enter URL"))
					  {
						  o.url(driver);
						  System.out.println(key);
					  }
					  else if(key.equals("Enter Username"))
					  {
						  o.username(driver,username);
						  System.out.println(key);
					  }
					  else if(key.equals("Enter Password"))
					  {
						  o.password(driver, password);
						  System.out.println(key);
					  }
					  else if(key.equals("Click On Login Button"))
					  {
						  o.loginButton(driver);
						  System.out.println(key);
					  }
					  else if(key.equals("Click On Admin Button"))
					  {
						  o.admin(driver);
						  System.out.println(key);
					  }
					  else if(key.equals("Click On Logout Button"))
					  {
						  o.logout(driver);
						  System.out.println(key);
						  System.out.println("Valid Cedential");
						  System.out.println("");
						  s.getRow(i).createCell(3).setCellValue("Valid Credential");
					  }	  	
				  }
				  catch(Exception e)
				  {
					  System.out.println("Invalid Cedential");
					  System.out.println("");
					  s.getRow(i).createCell(3).setCellValue("Invalid Credential");					  
				  }
			  }		  
		  }
		  FileOutputStream out =new FileOutputStream("C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\POI\\POI.xlsx");
		  w.write(out);
		  o.closeBrowser(driver);
	  }

}
