package repository_POM_PageFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwagLabs_MainClass
{
	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\sarin\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
				
		//Create object of POM class
		POM_SwagLabs p=new POM_SwagLabs();
		
		//Calling Methods
		p.maximizeBrowser(driver);
		p.deleteAllCookies(driver);
		p.implicitWait(driver);
		p.url(driver);
		p.username(driver, "standard_user");
		p.password(driver, "secret_sauce");
		p.loginButton(driver);
		
		driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("add-to-cart-sauce-labs-bolt-t-shirt")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[@class='shopping_cart_badge']")).click();
        Thread.sleep(2000);
		
		
		p.admin(driver);
		p.logout(driver);
		p.closeBrowser(driver);
		
	}

}